-- MySQL dump 10.13  Distrib 5.1.72, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: startups_dev
-- ------------------------------------------------------
-- Server version	5.1.72-0ubuntu0.10.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_5f412f9a` (`group_id`),
  KEY `auth_group_permissions_83d7f98b` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_37ef4eb4` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add user',4,'add_user'),(11,'Can change user',4,'change_user'),(12,'Can delete user',4,'delete_user'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add migration history',7,'add_migrationhistory'),(20,'Can change migration history',7,'change_migrationhistory'),(21,'Can delete migration history',7,'delete_migrationhistory'),(22,'Can add startup',8,'add_startup'),(23,'Can change startup',8,'change_startup'),(24,'Can delete startup',8,'delete_startup'),(25,'Can add recruiter',9,'add_recruiter'),(26,'Can change recruiter',9,'change_recruiter'),(27,'Can delete recruiter',9,'delete_recruiter'),(28,'Can add media outlet',10,'add_mediaoutlet'),(29,'Can change media outlet',10,'change_mediaoutlet'),(30,'Can delete media outlet',10,'delete_mediaoutlet');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$12000$qTwYFDqPKW9p$1jtb7we9RAoUsSlS5JIEZCp/Bc9vZfG9iTkmuLW59HM=','2013-11-15 19:05:14',1,'piousbox','','','piousbox@gmail.com',1,1,'2013-11-15 19:03:29');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_6340c63c` (`user_id`),
  KEY `auth_user_groups_5f412f9a` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_6340c63c` (`user_id`),
  KEY `auth_user_user_permissions_83d7f98b` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_6340c63c` (`user_id`),
  KEY `django_admin_log_37ef4eb4` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2013-11-15 19:09:42',1,8,'1','Airbnb',1,''),(2,'2013-11-15 19:09:53',1,8,'2','Beachmint',1,''),(3,'2013-11-15 19:09:57',1,8,'3','Beauchamp',1,''),(4,'2013-11-15 19:10:00',1,8,'4','Birchbox',1,''),(5,'2013-11-15 19:10:03',1,8,'5','Bluekai',1,''),(6,'2013-11-15 19:10:06',1,8,'6','Badoo',1,''),(7,'2013-11-15 19:10:09',1,8,'7','BOKU',1,''),(8,'2013-11-15 19:10:13',1,8,'8','Box.net',1,''),(9,'2013-11-15 19:10:16',1,8,'9','BranchOut',1,''),(10,'2013-11-15 19:10:20',1,8,'10','Cloudflare',1,''),(11,'2013-11-15 19:10:23',1,8,'11','Coupons.com',1,''),(12,'2013-11-15 19:11:01',1,8,'12','Zoosk',1,''),(13,'2013-11-15 19:11:05',1,8,'13','ZocDoc',1,''),(14,'2013-11-15 19:11:08',1,8,'14','Xoom',1,''),(15,'2013-11-15 19:11:11',1,8,'15','WePay',1,''),(16,'2013-11-15 19:11:14',1,8,'16','Warby Parker',1,''),(17,'2013-11-15 19:11:17',1,8,'17','Uber',1,''),(18,'2013-11-15 19:11:19',1,8,'18','Tumblr',1,''),(19,'2013-11-15 19:11:23',1,8,'19','Trunk Club',1,''),(20,'2013-11-15 19:11:26',1,8,'20','TrialPay',1,''),(21,'2013-11-15 19:11:29',1,8,'21','Square',1,''),(22,'2013-11-15 19:11:32',1,8,'22','Survey Monkey',1,''),(23,'2013-11-15 19:11:34',1,8,'23','Spotify',1,''),(24,'2013-11-15 19:11:37',1,8,'24','Specific Media',1,''),(25,'2013-11-15 19:11:40',1,8,'25','Klout',1,''),(26,'2013-11-15 19:11:42',1,8,'26','Narrative Science',1,''),(27,'2013-11-15 19:11:46',1,8,'27','Ness computing',1,''),(28,'2013-11-15 19:11:50',1,8,'28','Pinterest',1,''),(29,'2013-11-15 19:11:52',1,8,'29','One Kings Lane',1,''),(30,'2013-11-15 19:11:55',1,8,'30','Peixe Urbano',1,''),(31,'2013-11-15 19:11:58',1,8,'31','Polyvore',1,''),(32,'2013-11-15 19:12:00',1,8,'32','Quantcast',1,''),(33,'2013-11-15 19:12:03',1,8,'33','Quora',1,''),(34,'2013-11-15 19:12:05',1,8,'34','Rent The Runway',1,''),(35,'2013-11-15 19:12:08',1,8,'35','Rue la la',1,''),(36,'2013-11-15 19:12:10',1,8,'36','Rovio',1,''),(37,'2013-11-15 19:12:12',1,8,'37','Shopkick',1,''),(38,'2013-11-15 19:12:16',1,8,'38','DropBox',1,''),(39,'2013-11-15 19:12:19',1,8,'39','Eventbrite',1,''),(40,'2013-11-15 19:12:21',1,8,'40','Gogobot',1,''),(41,'2013-11-15 19:12:23',1,8,'41','Hipmunk',1,''),(42,'2013-11-15 19:12:26',1,8,'42','Instagram',1,''),(43,'2013-11-15 19:12:30',1,8,'43','Jawbone',1,''),(44,'2013-11-15 19:22:57',1,8,'44','Moqups',1,''),(45,'2013-11-15 19:23:54',1,8,'45','Iconify',1,''),(46,'2013-11-15 19:24:11',1,8,'46','Fiestah',1,''),(47,'2013-11-15 19:24:21',1,8,'47','Mevvy',1,''),(48,'2013-11-15 19:24:27',1,8,'48','HealthAware',1,''),(49,'2013-11-15 19:24:32',1,8,'49','Mover.io',1,''),(50,'2013-11-15 19:24:37',1,8,'50','Artery',1,''),(51,'2013-11-15 19:24:43',1,8,'51','Taurus',1,''),(52,'2013-11-15 19:24:50',1,8,'52','Typeform',1,''),(53,'2013-11-15 19:24:55',1,8,'53','Home Classmate',1,''),(54,'2013-11-15 19:25:00',1,8,'54','Merge',1,''),(55,'2013-11-15 19:25:09',1,8,'55','Kera',1,''),(56,'2013-11-15 19:25:14',1,8,'56','Heatma.ps',1,''),(57,'2013-11-15 19:25:20',1,8,'57','Cappture',1,''),(58,'2013-11-15 19:25:26',1,8,'58','StageBloc',1,''),(59,'2013-11-15 19:25:31',1,8,'59','Erli Bird',1,''),(60,'2013-11-15 19:25:35',1,8,'60','Propeller',1,''),(61,'2013-11-15 19:25:39',1,8,'61','App Press',1,''),(62,'2013-11-15 19:25:45',1,8,'62','Much Better Adventures',1,''),(63,'2013-11-15 19:25:50',1,8,'63','Payhip',1,''),(64,'2013-11-15 19:25:58',1,8,'64','Spark',1,''),(65,'2013-11-15 19:26:05',1,8,'65','Have 1 On Me',1,''),(66,'2013-11-15 19:26:10',1,8,'66','Kareer',1,''),(67,'2013-11-15 19:26:15',1,8,'67','Show On The Cloud',1,''),(68,'2013-11-15 19:26:19',1,8,'68','Space Box',1,''),(69,'2013-11-15 19:26:24',1,8,'69','Famest',1,''),(70,'2013-11-15 19:26:29',1,8,'70','GameWisp',1,''),(71,'2013-11-15 19:26:34',1,8,'71','Wrap Bootstrap',1,''),(72,'2013-11-15 19:26:43',1,8,'72','Copybar',1,''),(73,'2013-11-15 19:26:48',1,8,'73','Taskup',1,''),(74,'2013-11-15 19:26:54',1,8,'74','ImageFly',1,''),(75,'2013-11-15 19:26:59',1,8,'75','Pluto',1,''),(76,'2013-11-15 19:27:05',1,8,'76','Welovroi',1,''),(77,'2013-11-15 19:27:10',1,8,'77','Quivee',1,''),(78,'2013-11-15 19:27:17',1,8,'78','Receiveee',1,''),(79,'2013-11-15 19:27:23',1,8,'79','Only Coin',1,''),(80,'2013-11-15 19:29:18',1,8,'79','Only Coin',2,'Changed has_vacancy.'),(81,'2013-11-15 19:32:16',1,8,'80','Wipro',1,''),(82,'2013-11-15 19:33:38',1,9,'1','Mastech',1,''),(83,'2013-11-15 19:33:51',1,9,'2','Jobspring Chicago',1,''),(84,'2013-11-15 19:46:31',1,8,'81','Scout',1,''),(85,'2013-11-15 19:47:18',1,8,'81','Scout',2,'Changed city_name.'),(86,'2013-11-15 20:00:45',1,8,'1','Airbnb',2,'Changed has_applied and applied_on.'),(87,'2013-11-15 20:04:38',1,10,'1','TNW - the next web',1,''),(88,'2013-11-15 20:04:43',1,10,'2','techvibes',1,''),(89,'2013-11-15 20:04:47',1,10,'3','tech crunch',1,''),(90,'2013-11-15 20:04:51',1,10,'4','kickstarter',1,'');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'log entry','admin','logentry'),(2,'permission','auth','permission'),(3,'group','auth','group'),(4,'user','auth','user'),(5,'content type','contenttypes','contenttype'),(6,'session','sessions','session'),(7,'migration history','south','migrationhistory'),(8,'startup','startups_list','startup'),(9,'recruiter','startups_list','recruiter'),(10,'media outlet','startups_list','mediaoutlet');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_b7b81f0c` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('8h82nhrsy8uhoqyqprjcf7rfuxdr701t','ZTRlMDlkZjY4Y2Y5Mzg5NjUzYWY0ZDMzZjJkNjk3OWMyZDI2YjEzODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=','2013-11-29 19:05:14');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `south_migrationhistory`
--

DROP TABLE IF EXISTS `south_migrationhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `south_migrationhistory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(255) NOT NULL,
  `migration` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `south_migrationhistory`
--

LOCK TABLES `south_migrationhistory` WRITE;
/*!40000 ALTER TABLE `south_migrationhistory` DISABLE KEYS */;
INSERT INTO `south_migrationhistory` VALUES (1,'startups_list','0001_initial','2013-11-15 19:03:57'),(5,'startups_list','0003_auto__add_field_startup_city_name','2013-11-15 19:47:07'),(4,'startups_list','0002_auto__add_field_startup_has_vacancy','2013-11-15 19:28:57'),(6,'startups_list','0004_auto__add_field_startup_has_applied','2013-11-15 19:47:55'),(7,'startups_list','0005_auto__add_field_startup_applied_on','2013-11-15 19:57:34');
/*!40000 ALTER TABLE `south_migrationhistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `startups_list_mediaoutlet`
--

DROP TABLE IF EXISTS `startups_list_mediaoutlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `startups_list_mediaoutlet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256),
  `website_url` varchar(256),
  `descr` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `startups_list_mediaoutlet`
--

LOCK TABLES `startups_list_mediaoutlet` WRITE;
/*!40000 ALTER TABLE `startups_list_mediaoutlet` DISABLE KEYS */;
INSERT INTO `startups_list_mediaoutlet` VALUES (1,'TNW - the next web','',''),(2,'techvibes','',''),(3,'tech crunch','',''),(4,'kickstarter','','');
/*!40000 ALTER TABLE `startups_list_mediaoutlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `startups_list_recruiter`
--

DROP TABLE IF EXISTS `startups_list_recruiter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `startups_list_recruiter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200),
  `website_url` varchar(200),
  `descr` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `startups_list_recruiter_name_7cf3c834_uniq` (`name`),
  UNIQUE KEY `startups_list_recruiter_website_url_169871f9_uniq` (`website_url`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `startups_list_recruiter`
--

LOCK TABLES `startups_list_recruiter` WRITE;
/*!40000 ALTER TABLE `startups_list_recruiter` DISABLE KEYS */;
INSERT INTO `startups_list_recruiter` VALUES (1,'Mastech','http://mastech.com',''),(2,'Jobspring Chicago','','');
/*!40000 ALTER TABLE `startups_list_recruiter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `startups_list_startup`
--

DROP TABLE IF EXISTS `startups_list_startup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `startups_list_startup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200),
  `website_url` varchar(200),
  `descr` longtext,
  `has_vacancy` tinyint(1) NOT NULL,
  `city_name` varchar(200),
  `has_applied` tinyint(1) NOT NULL,
  `applied_on` date,
  PRIMARY KEY (`id`),
  UNIQUE KEY `startups_list_startup_name_6b93f16a_uniq` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `startups_list_startup`
--

LOCK TABLES `startups_list_startup` WRITE;
/*!40000 ALTER TABLE `startups_list_startup` DISABLE KEYS */;
INSERT INTO `startups_list_startup` VALUES (1,'Airbnb','','',1,'',1,'2013-11-15'),(2,'Beachmint','','',1,NULL,0,NULL),(3,'Beauchamp','','',1,NULL,0,NULL),(4,'Birchbox','','',1,NULL,0,NULL),(5,'Bluekai','','',1,NULL,0,NULL),(6,'Badoo','','',1,NULL,0,NULL),(7,'BOKU','','',1,NULL,0,NULL),(8,'Box.net','','',1,NULL,0,NULL),(9,'BranchOut','','',1,NULL,0,NULL),(10,'Cloudflare','','',1,NULL,0,NULL),(11,'Coupons.com','Coupons.com','',1,NULL,0,NULL),(12,'Zoosk','','',1,NULL,0,NULL),(13,'ZocDoc','','',1,NULL,0,NULL),(14,'Xoom','','',1,NULL,0,NULL),(15,'WePay','','',1,NULL,0,NULL),(16,'Warby Parker','','',1,NULL,0,NULL),(17,'Uber','','',1,NULL,0,NULL),(18,'Tumblr','','',1,NULL,0,NULL),(19,'Trunk Club','','',1,NULL,0,NULL),(20,'TrialPay','','',1,NULL,0,NULL),(21,'Square','','',1,NULL,0,NULL),(22,'Survey Monkey','','',1,NULL,0,NULL),(23,'Spotify','','',1,NULL,0,NULL),(24,'Specific Media','','',1,NULL,0,NULL),(25,'Klout','','',1,NULL,0,NULL),(26,'Narrative Science','','',1,NULL,0,NULL),(27,'Ness computing','','',1,NULL,0,NULL),(28,'Pinterest','','',1,NULL,0,NULL),(29,'One Kings Lane','','',1,NULL,0,NULL),(30,'Peixe Urbano','','',1,NULL,0,NULL),(31,'Polyvore','','',1,NULL,0,NULL),(32,'Quantcast','','',1,NULL,0,NULL),(33,'Quora','','',1,NULL,0,NULL),(34,'Rent The Runway','','',1,NULL,0,NULL),(35,'Rue la la','','',1,NULL,0,NULL),(36,'Rovio','','',1,NULL,0,NULL),(37,'Shopkick','','',1,NULL,0,NULL),(38,'DropBox','','',1,NULL,0,NULL),(39,'Eventbrite','','',1,NULL,0,NULL),(40,'Gogobot','','',1,NULL,0,NULL),(41,'Hipmunk','','',1,NULL,0,NULL),(42,'Instagram','','',1,NULL,0,NULL),(43,'Jawbone','','',1,NULL,0,NULL),(44,'Moqups','https://moqups.com/#!/','',1,NULL,0,NULL),(45,'Iconify','http://iconify.co/','',1,NULL,0,NULL),(46,'Fiestah','http://www.fiestah.com/','No vacancy 2013-11-15',1,NULL,0,NULL),(47,'Mevvy','http://relaunch.mevvy.com/','',1,NULL,0,NULL),(48,'HealthAware','http://healthaware.ca/','',1,NULL,0,NULL),(49,'Mover.io','http://mover.io/','',1,NULL,0,NULL),(50,'Artery','https://artery.io/','',1,NULL,0,NULL),(51,'Taurus','http://taurus.io/','',1,NULL,0,NULL),(52,'Typeform','http://www.typeform.com/','',1,NULL,0,NULL),(53,'Home Classmate','http://www.homeclassmate.com/','',1,NULL,0,NULL),(54,'Merge','https://www.mergehq.com/','',1,NULL,0,NULL),(55,'Kera','https://www.kera.io/','',1,NULL,0,NULL),(56,'Heatma.ps','https://heatma.ps/','',1,NULL,0,NULL),(57,'Cappture','http://capptureapp.com/','',1,NULL,0,NULL),(58,'StageBloc','http://stagebloc.com/','',1,NULL,0,NULL),(59,'Erli Bird','http://erlibird.com/','',1,NULL,0,NULL),(60,'Propeller','http://usepropeller.com/','',1,NULL,0,NULL),(61,'App Press','http://www.app-press.com/','',1,NULL,0,NULL),(62,'Much Better Adventures','http://www.muchbetteradventures.com/','',1,NULL,0,NULL),(63,'Payhip','https://payhip.com/','',1,NULL,0,NULL),(64,'Spark','','No thanks; only mobile.',1,NULL,0,NULL),(65,'Have 1 On Me','http://1onme.com/','',1,NULL,0,NULL),(66,'Kareer','http://kareer.me/','',1,NULL,0,NULL),(67,'Show On The Cloud','http://showonthecloud.com/','',1,NULL,0,NULL),(68,'Space Box','https://spacebox.io/','',1,NULL,0,NULL),(69,'Famest','http://www.famest.com/','',1,NULL,0,NULL),(70,'GameWisp','http://gamewisp.com/','',1,NULL,0,NULL),(71,'Wrap Bootstrap','https://wrapbootstrap.com/','',1,NULL,0,NULL),(72,'Copybar','https://copybar.io/','',1,NULL,0,NULL),(73,'Taskup','https://taskup.com/','',1,NULL,0,NULL),(74,'ImageFly','http://imageflyapp.com/','',1,NULL,0,NULL),(75,'Pluto','http://discoverpluto.com/index.php','',1,NULL,0,NULL),(76,'Welovroi','http://www.welovroi.com/','',1,NULL,0,NULL),(77,'Quivee','http://www.quivee.com/','',1,NULL,0,NULL),(78,'Receiveee','http://receiveee.com/','',1,NULL,0,NULL),(79,'Only Coin','','No Vacancy',0,NULL,0,NULL),(80,'Wipro','','',1,NULL,0,NULL),(81,'Scout','www.scoutrfp.com','Yes has vacancy - 2013-11-15',1,'Chicago, IL',0,NULL);
/*!40000 ALTER TABLE `startups_list_startup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-11-15 12:06:12
